package com.zento.onlinestore;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.messaging.FirebaseMessaging;

/**
 * Zento Online Store app.
 *
 * A thin native shell around the live store. Every product, login, cart and
 * order still goes through the same Render server and database, so changes you
 * push to the website show up in the app without rebuilding it.
 */
public class MainActivity extends Activity {

    private static final String HOME_URL = "https://zento-e-commerce-all.onrender.com/seller/";
    private static final String HOME_HOST = "zento-e-commerce-all.onrender.com";

    private static final int LIGHT_SURFACE = 0xFFFFFFFF;
    private static final int DARK_SURFACE = 0xFF0F1830;

    private WebView webView;
    private View root;
    private View loadingView;
    private View errorView;
    private TextView loadingText;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable wakingHint = new Runnable() {
        @Override
        public void run() {
            if (loadingText != null) {
                loadingText.setText(R.string.loading_slow);
            }
        }
    };

    private static final int FILE_REQUEST = 4501;
    private ValueCallback<Uri[]> filePathCallback;

    static volatile boolean visible = false;
    private String pendingTarget = "";

    private boolean hasError = false;
    private boolean darkTheme = false;
    private long lastBackPress = 0;

    /* ---------------------------------------------------------
       LIFECYCLE
    --------------------------------------------------------- */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        root = findViewById(R.id.root);
        webView = findViewById(R.id.webview);
        loadingView = findViewById(R.id.loading);
        errorView = findViewById(R.id.error);
        loadingText = findViewById(R.id.loading_text);

        int nightMask = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        darkTheme = nightMask == Configuration.UI_MODE_NIGHT_YES;

        setupEdgeToEdge();
        applyBars();
        setupWebView();

        findViewById(R.id.retry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadHome();
            }
        });

        pendingTarget = readTarget(getIntent());

        setupPush();
        loadHome();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);

        String target = readTarget(intent);

        if (!target.isEmpty()) {
            pendingTarget = target;
            runPendingTarget();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQUEST) {
            if (filePathCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        webView.onResume();
        applyBars();
    }

    @Override
    protected void onPause() {
        visible = false;
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(wakingHint);
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }

    /* ---------------------------------------------------------
       BACK BUTTON
       The store closes its own cart, checkout, profile and
       product screens first. Pressing back twice leaves the app.
    --------------------------------------------------------- */

    @Override
    public void onBackPressed() {
        if (loadingView.getVisibility() == View.VISIBLE || errorView.getVisibility() == View.VISIBLE) {
            exitOnDoubleBack();
            return;
        }

        String script = "(function(){try{return !!(window.zentoHandleBack && window.zentoHandleBack());}catch(e){return false;}})()";

        webView.evaluateJavascript(script, new android.webkit.ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (!"true".equals(value)) {
                    exitOnDoubleBack();
                }
            }
        });
    }

    private void exitOnDoubleBack() {
        long now = System.currentTimeMillis();

        if (now - lastBackPress < 2000) {
            finish();
        } else {
            lastBackPress = now;
            Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show();
        }
    }

    /* ---------------------------------------------------------
       PUSH NOTIFICATIONS
    --------------------------------------------------------- */

    private String readTarget(Intent intent) {
        if (intent == null) {
            return "";
        }

        String target = intent.getStringExtra("target");
        return target == null ? "" : target;
    }

    private void setupPush() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7001);
        }

        try {
            FirebaseMessaging.getInstance().getToken().addOnSuccessListener(new com.google.android.gms.tasks.OnSuccessListener<String>() {
                @Override
                public void onSuccess(String token) {
                    if (token == null) {
                        return;
                    }

                    getSharedPreferences("zento_push", MODE_PRIVATE).edit().putString("token", token).apply();
                    registerPushInPage();
                }
            });
        } catch (Throwable ignored) {
            // Firebase is not set up (no google-services.json). The app works without push.
        }
    }

    private void registerPushInPage() {
        if (webView == null) {
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{window.zentoRegisterPush&&window.zentoRegisterPush();}catch(e){}})()", null);
    }

    private void runPendingTarget() {
        if (pendingTarget == null || pendingTarget.isEmpty() || webView == null || loadingView.getVisibility() == View.VISIBLE) {
            return;
        }

        String target = pendingTarget.replaceAll("[^a-z_]", "");
        pendingTarget = "";

        webView.evaluateJavascript(
                "(function(){try{window.zentoOpenTarget&&window.zentoOpenTarget('" + target + "');}catch(e){}})()", null);
    }

    /* ---------------------------------------------------------
       LOADING AND ERROR SCREENS
    --------------------------------------------------------- */

    private void loadHome() {
        hasError = false;
        loadingText.setText(R.string.loading);
        loadingView.setVisibility(View.VISIBLE);
        errorView.setVisibility(View.GONE);

        handler.removeCallbacks(wakingHint);
        handler.postDelayed(wakingHint, 7000);

        webView.loadUrl(HOME_URL);
    }

    private void showContent() {
        handler.removeCallbacks(wakingHint);
        loadingView.setVisibility(View.GONE);
        errorView.setVisibility(View.GONE);
    }

    private void showError() {
        hasError = true;
        handler.removeCallbacks(wakingHint);
        loadingView.setVisibility(View.GONE);
        errorView.setVisibility(View.VISIBLE);
    }

    /* ---------------------------------------------------------
       WEBVIEW
    --------------------------------------------------------- */

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setUserAgentString(settings.getUserAgentString() + " ZentoApp/1.0");

        CookieManager.getInstance().setAcceptCookie(true);

        webView.setBackgroundColor(Color.TRANSPARENT);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.addJavascriptInterface(new NativeBridge(), "ZentoNative");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");

                try {
                    startActivityForResult(Intent.createChooser(intent, "Choose image"), FILE_REQUEST);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openOutsideIfNeeded(request.getUrl());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!hasError) {
                    showContent();
                    registerPushInPage();
                    runPendingTarget();
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    showError();
                }
            }
        });
    }

    /** Pages of the store stay inside the app. Everything else opens in the right app. */
    private boolean openOutsideIfNeeded(Uri uri) {
        if ("https".equals(uri.getScheme()) && HOME_HOST.equals(uri.getHost())) {
            return false;
        }

        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ignored) {
            // No app can open this link.
        }

        return true;
    }

    /** Lets the website tell the app which theme is active, so the status bar matches. */
    public class NativeBridge {
        @JavascriptInterface
        public String getPushToken() {
            return getSharedPreferences("zento_push", MODE_PRIVATE).getString("token", "");
        }

        @JavascriptInterface
        public void setTheme(String theme) {
            final boolean dark = "dark".equals(theme);

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    darkTheme = dark;
                    applyBars();
                }
            });
        }
    }

    /* ---------------------------------------------------------
       FULL SCREEN LAYOUT AND SYSTEM BARS
    --------------------------------------------------------- */

    private void setupEdgeToEdge() {
        Window window = getWindow();

        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
        }

        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(params);
        }

        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
        }

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                int left;
                int top;
                int right;
                int bottom;

                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets bars = insets.getInsets(
                            WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                    android.graphics.Insets keyboard = insets.getInsets(WindowInsets.Type.ime());

                    left = bars.left;
                    top = bars.top;
                    right = bars.right;
                    bottom = Math.max(bars.bottom, keyboard.bottom);
                } else {
                    left = insets.getSystemWindowInsetLeft();
                    top = insets.getSystemWindowInsetTop();
                    right = insets.getSystemWindowInsetRight();
                    bottom = insets.getSystemWindowInsetBottom();
                }

                view.setPadding(left, top, right, bottom);
                return insets;
            }
        });

        root.requestApplyInsets();
    }

    private void applyBars() {
        Window window = getWindow();
        boolean lightBars = !darkTheme;

        root.setBackgroundColor(darkTheme ? DARK_SURFACE : LIGHT_SURFACE);

        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = window.getInsetsController();

            if (controller != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                controller.setSystemBarsAppearance(lightBars ? mask : 0, mask);
            }
        } else {
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;

            if (lightBars && Build.VERSION.SDK_INT >= 23) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }

            if (lightBars && Build.VERSION.SDK_INT >= 26) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }

            window.getDecorView().setSystemUiVisibility(flags);
        }
    }
}
