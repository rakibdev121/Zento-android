# Zento Android app

A native Android shell around the live Zento Online Store
(`https://zento-e-commerce-all.onrender.com/`).

The app has no backend of its own. Products, login, cart, checkout and orders all use
the same Render server and database as the website, so website updates appear in the app
without a rebuild.

## Build the APK

Every push to `main` builds the APK on GitHub (Actions tab, "Build Android APK").
Download `Zento.apk` from the **Releases** page (tag `latest`) or from the run's artifacts.

To change the store address, edit `HOME_URL` and `HOME_HOST` in
`app/src/main/java/com/zento/onlinestore/MainActivity.java`.

## Notes

- Build tools: Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, compileSdk 35, minSdk 24.
- `app/debug.keystore` is the standard public debug key. It keeps every build signed the
  same way so updates install over older versions. Use a private release key before
  publishing to Google Play.
